% AleeEEG(): prototipe of local and individual analysis

%% Load info from database
jsonText = fileread('ds004584/participants.json');
jsonData = jsondecode(jsonText);
dataTable = readtable('ds004584/participants.tsv', 'FileType', 'text');

% Remember run in the beginning to have available reading resources
% eeglab;

%% Only run this loop if all data are available in local

[nCases,~] = size(dataTable);

paramPacienteAll = zeros(nCases,6*63+1); % +1 for PSD
locsPacienteAll = {}; 

% for j=1:height(dataTable)
for j=1:149
    %% Load info of a specific patient
    myid = dataTable.participant_id{j};
    myfileset  = [myid, '_task-Rest_eeg.set'];
    myfilepath = ['ds004584/', myid, '/eeg/'];
    disp("Reading " + myid);

    EEG = pop_loadset('filename', myfileset, ...
        'filepath',myfilepath);

    %EEG = pop_loadset('filename', 'sub-001_task-Rest_eeg.set', ...
    %    'filepath','./sub-001/eeg/');
    fs = EEG.srate;
    locs = EEG.chanlocs;
    eegData = EEG.data; % In rows

    %% Processing a single patient
    [nchann,nsamples] = size(eegData);
    if nchann>63 
        disp('Found recording with non-standard channels'),
        nchann=63;
    end
    paramPaciente = zeros(1,nchann*6+1); % +1 for PSD
    locsPaciente = cell(1,nchann);
    
    for i=1: nchann % For each channel in this subject
        %fprintf(1,'\b\b\b %d ..', i);
        x = eegData(i,:);
        t = 1/fs*(0:length(x)-1);

        % Plot, detrend, see spectrum, filtering, Welch periodogram
        plotflag = 0;
        xclean = cleanEEG(double(x),t,plotflag);
        if plotflag,
            figure(20)
            plot(xclean);
        end

        % Get lpc parameters
        a = lpc(xclean,6);
        h = impz(1,a,80); 
        [H,f] = freqz(1,a);
        if plotflag
            figure(80)
            subplot(221), zplane(1,a);
            subplot(222), stem(h)
            subplot(223), plot(f,abs(H));
        end

        % Get spectrogram
        [s,f,t] = spectrogram(xclean,hamming(1*fs),fs/2,1024,fs);
        if plotflag
            figure(70)
            surf(t,f,abs(s))
            %surf(t,f,log10(abs(s)+1));     % If we want see in log uinits
            shading interp, view(110,30);
        end

        % Choose a property to aggreagate on each channel
        % disp('Work in progress ...')
        paramPaciente((i-1)*6+1:(i)*6) = a(2:end);
        locsPaciente{i} = locs(i).labels;
        %disp('Press any key to continue'), pause;
    end
    
    % Calculate Power Spectral Density (PSD)
    % PSD is computed as the mean power across all frequencies for each channel
    psd = mean(abs(s),2); % Average across time
    paramPaciente(end) = mean(psd); % Append PSD to feature vector
%     
    % Calculate Spectral Entropy
    spectralEntropy = -sum(psd.*log(psd))/log(length(psd)); % Shannon entropy
    paramPaciente(end) = spectralEntropy; % Append spectral entropy to feature vector
%     
    % Rewrite for not growing inside the loop
    paramPacienteAll(j,:) = paramPaciente;
    locsPacienteAll = [locsPacienteAll; locsPaciente]; 
    fprintf(1,'\n');
    

end

% locsPacienteAll(:,53)     % Check channels

% Store params with channel labels
save myBase paramPacienteAll locsPacienteAll dataTable

%% Train Random Forest classifier
X = paramPacienteAll; % Features matrix
Y = dataTable.TYPE; % Target labels

% Train Random Forest classifier
numTrees = 100; % Number of trees in the forest (you can adjust this)
model = TreeBagger(numTrees, X, Y, 'Method', 'classification');

% Predict labels using trained model (Optional)
% Y_pred = predict(model, X);

%% Fast representation of feature contraction with PCA and tSNE
% Apply PCA
X_pca = pca(X);
% Apply tSNE to the PCA-transformed data
Xt = tsne(X_pca);

% Plot tSNE representation
Yt = dataTable.TYPE;
ind1 = find(Yt==1); % PD
ind0 = find(Yt==0); % control
figure(75)
perplexity_values = [5, 10, 20, 30, 50];
figure;
for i = 1:length(perplexity_values)
    perplexity = perplexity_values(i);
    Xt = tsne(X_pca, 'Perplexity', perplexity);
    
    subplot(2, 3, i);
    plot(Xt(ind1, 1), Xt(ind1, 2), 'xr', Xt(ind0, 1), Xt(ind0, 2), 'ob');
    title(['Perplexity = ', num2str(perplexity)]);
    xlabel('tSNE Dimension 1');
    ylabel('tSNE Dimension 2');
end
