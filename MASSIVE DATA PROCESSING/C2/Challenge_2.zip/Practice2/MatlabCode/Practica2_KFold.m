% Load info from database
jsonText = fileread('ds004584/participants.json');
jsonData = jsondecode(jsonText);
dataTable = readtable('ds004584/participants.tsv', 'FileType', 'text');

% Initialize variables
[nCases,~] = size(dataTable);
paramPacienteAll = zeros(nCases,6*63+2); % +2 for PSD and spectral entropy
locsPacienteAll = {}; 

% Loop over patients
for j = 1:149
    % Load EEG data
    myid = dataTable.participant_id{j};
    myfileset = [myid, '_task-Rest_eeg.set'];
    myfilepath = ['ds004584/', myid, '/eeg/'];
    EEG = pop_loadset('filename', myfileset, 'filepath',myfilepath);
    fs = EEG.srate;
    locs = EEG.chanlocs;
    eegData = EEG.data;
    
    % Preprocessing and feature extraction
    [nchann,~] = size(eegData);
    nchann = min(nchann, 63); % Ensure no more than 63 channels are processed
    paramPaciente = zeros(1,nchann*6+2); % +2 for PSD and spectral entropy
    locsPaciente = cell(1,nchann);
    for i = 1:nchann
        x = eegData(i,:);
        t = 1/fs*(0:length(x)-1);
        xclean = cleanEEG(double(x),t,0); % Assume cleanEEG is a defined function
        a = lpc(xclean,6);
        
        % Spectrogram
        [s,~,~] = spectrogram(xclean,hamming(1*fs),fs/2,1024,fs);
        
        % Features
        paramPaciente((i-1)*6+1:(i)*6) = a(2:end);
        locsPaciente{i} = locs(i).labels;
    end
    psd = mean(abs(s),2);
    paramPaciente(end-1) = mean(psd);
    spectralEntropy = -sum(psd.*log(psd))/log(length(psd));
    paramPaciente(end) = spectralEntropy;
    
    % Store extracted features
    paramPacienteAll(j,:) = paramPaciente;
    locsPacienteAll = [locsPacienteAll; locsPaciente]; 
end
%%
% Load data and preprocess as in the previous section

% Prepare data for classification
X = paramPacienteAll;
Y = dataTable.TYPE;

% 10-fold cross-validation setup
cv = cvpartition(Y, 'KFold', 10);

% Initialize variables for accuracy
accuracy = zeros(cv.NumTestSets, 1);
featureImportance = zeros(size(X, 2), 1);

% Perform cross-validation
% Perform cross-validation
for i = 1:cv.NumTestSets
    trainIdx = cv.training(i);
    testIdx = cv.test(i);
    
    % Train Random Forest with OOB Predictor Importance enabled
    model = TreeBagger(100, X(trainIdx,:), Y(trainIdx), 'Method', 'classification', 'OOBPrediction', 'On', 'OOBPredictorImportance', 'On');
    predictions = predict(model, X(testIdx,:));
    predictions = str2double(predictions); % Convert predictions to numeric
    
    % Calculate accuracy
    accuracy(i) = sum(predictions == Y(testIdx)) / numel(Y(testIdx));
    
    % Aggregate feature importance
    featureImportance = featureImportance + model.OOBPermutedVarDeltaError';
end

% Calculate mean accuracy
meanAccuracy = mean(accuracy);
fprintf('Average Accuracy: %.2f%%\n', meanAccuracy * 100);

% Average feature importance
featureImportance = featureImportance / cv.NumTestSets;

% Select top features based on importance
[sortedImportance, idx] = sort(featureImportance, 'descend');
topFeatures = idx(1:20); % Select top 20 features

% Apply t-SNE on selected features
X_selected = X(:, topFeatures);
perplexity = 10; % Set perplexity for t-SNE
tsneResults = tsne(X_selected, 'Algorithm','barneshut','Perplexity',perplexity);

% Visualize t-SNE results with different markers for each group
figure;
hold on;
% Indices for each group
indPD = find(Y == 1); % Assuming 1 represents PD
indControl = find(Y == 0); % Assuming 0 represents Control

% Plot each group with different markers
scatter(tsneResults(indPD, 1), tsneResults(indPD, 2), 'xr', 'DisplayName', 'PD'); % PD with red crosses
scatter(tsneResults(indControl, 1), tsneResults(indControl, 2), 'ob', 'DisplayName', 'Control'); % Control with blue dots

title('t-SNE Visualization of EEG Features');
xlabel('Dimension 1');
ylabel('Dimension 2');
legend show;
hold off;





