%
% SAMPLE NSG MATLAB SCRIPT USING EEGLAB TO PROCESS A NEMAR/OPENNEURO DATASET
%
bidsName = 'ds004584'   % The NEMAR/OpenNeuro ID of the dataset you want to process
 
%
% Start up EEGLAB within the NSG session
%
eeglab;                  % Open the EEGLAB environment
%
% Build the NEMAR address of the selected dataset
%
filePath = [ getenv('NEMARPATH') bidsName ]; % NEMARPATH is a global variable in NSG MATLAB
                                        %      pointing to the NEMAR data directory.
[status cwd] = system('pwd');                     % Get the current working directory on NSG.
cwd = strip(cwd);                              % Remove whitespace from path directory under the pwd
out_dir = fullfile(cwd, 'eegbidsout');  %   in which to put the EEGLAB Study files.
%
[STUDY,EEG] = pop_importbids(filePath, 'outputdir', out_dir); % Import the BIDS dataset
                                                              %   as an EEGLAB STUDY
                                                              %   in the named subdir.
%
% Test example: Here simply query the imported STUDY and print some results into an ascii file.
%
fid = fopen('results.txt', 'w');  % Open a text file to store dataset information returned below
%
fprintf(fid,'***************************\n');                % Print to an output information file:
fprintf(fid,'BIDS dataset %s\n', bidsName);                  % - the OpenNeuro/NEMAR dataset ID
fprintf(fid,'***************************\n');
fprintf(fid,'%d datasets\n', length(EEG));                   % - the total number of EEG data files
fprintf(fid,'%d to %d channels\n', ...
           min([EEG.nbchan]), max([EEG.nbchan]));            % - their range of EEG channel numbers
fprintf(fid,'%d to %d seconds\n', ...
           round(min([EEG.pnts])/EEG(1).srate), round(max([EEG.pnts])/EEG(1).srate));
                                                             % - their range of durations in sec
fprintf(fid,'%d to %d events\n', ...
           min(cellfun(@length, {EEG.event})), max(cellfun(@length, {EEG.event})));
                                                             % - their range of event numbers
fclose(fid);           % Close the ascii information file
type('results.txt');   % Print the name of the output information file as a reminder
%
% NOTE: By default, the EEGLAB study
%   converted from the BIDS repository will be saved for download  
%   ALONG WITH any results files your script has created.
% When you do NOT need to download the STUDY data files (which may be large),
%   but only the results derived by this script,
% MAKE SURE TO DELETE all the STUDY files (as below) before ending your script.
%
rmdir(out_dir, 's') % Remove the imported STUDY files to avoid a large unneeded download

