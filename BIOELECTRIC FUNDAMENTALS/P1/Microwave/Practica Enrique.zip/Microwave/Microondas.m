clear; clc; close all
addpath("C:\Users\enriq\OneDrive\Documentos\MATLAB\Microwave\Microwave\Funciones")
% Two loads and one test are created and displayed
figure; hold on; grid on;
[qs(1),rs(1,:)]=DrawCharge(1e-6, [1, 0, 0]); % Carga positiva del dipolo
[qs(2),rs(2,:)]=DrawCharge(-1e-6, [-1, 0, 0]); % Cargar negativa del dipolo
qe(1)=-1; re(1,:)=[-1000, -1000, 0];
qe(2)=1; re(2,:)=[1000, 1000, -0];

[X,Y] = meshgrid(linspace(-1,1,100),linspace(-1,1,100)); % XY plane
d = 0.001; % Distance from the charges to the XY plane
Z = d*ones(size(X));
R = [X(:) Y(:) Z(:)];  
Et = zeros(size(R));
for i=1:length(qe)
    Et = Et + ElectricField(re(i,:),R,qe(i));
end
Ex = reshape(Et(:,1),size(X));
Ey = reshape(Et(:,2), size(X));
streamslice(X,Y,Ex,Ey); axis tight

A2=rs(2,:)-rs(1,:)
P=A2*qs(1)
T=cross(P,Et(1,:))
Vector=[0 2 0];
DrawVectorArrow=@(posOrigin,Vector,varargin) quiver3(posOrigin(1),posOrigin(2),posOrigin(3),forceVector(1),forceVector(2),forceVector(3),varargin{:});
angulos1=linspace(0,2*pi,100);
angulos2=linspace(pi,-pi,100); % Angles of the circular path
radio=norm(A2)/2; % Circular path radius
o=findobj(gca, 'Marker','.');
for i=1:length(angulos1)
    posicion1 = radio*exp(1i*angulos1(i));
    posicion2 = radio*exp(-1i*angulos2(i));
    rs(1,:) = [real(posicion1) imag(posicion1) 0];
    rs(2,:) = [real(posicion2) imag(posicion2) 0];
    o(1).XData=rs(1,1); o(1).YData=rs(1,2); plot(rs(1,1),rs(1,2),'.','MarkerSize',30','Color', [255,87,51]/255)
    o(2).XData=rs(2,1); o(2).YData=rs(2,2); plot(rs(2,1),rs(2,2),'.','MarkerSize',30','Color', [93,173,226]/255)
    axis equal; xlabel('x (m)'), ylabel('y (m)');
    drawnow, pause(.1), hold on, view(0,90)
end


%%
clear all; clear; clc