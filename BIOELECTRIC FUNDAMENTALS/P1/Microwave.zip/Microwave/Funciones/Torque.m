function T=Torque(qs, E)
